import React,{Component} from 'react';
import {Breadcrumb,Icon,  Segment, Card, Image, Grid, Button, Header } from 'semantic-ui-react';
import {Link} from 'react-router-dom';
import {connect} from 'react-redux';
class Product extends Component{
  constructor(props){
    super(props);
    this.state = {data: null, images : '',users : null, loading: true}
  }
componentDidMount(){
  let fetchObj = {
    method: 'GET', 
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
       'Authorization' : 'Bearer ' + this.props.authen
    }
  }
  fetch(`http://139.59.87.122/modtod/beta/api/product/detail/${this.props.match.params.id}`, fetchObj)
  .then(res => {
    if(res.status !==200){
      throw new Error('INSIDE FETCH');
    }
    else{
      return res.json();
    }
  })
  .then(result => {
    this.setState({data : result.data})
    this.setState({users : result.data.user})
    this.setState({image: result.data.images[0], loading: false})
    console.log(this.state.image)
  }
  )

}



  render(){
    return(
      <div>
        
        <Segment>
            
          <Breadcrumb size = 'big'>
        <Link to = '/product/productListings'><Breadcrumb.Section >ProductListing</Breadcrumb.Section></Link>
        <Breadcrumb.Divider />
        <Breadcrumb.Section active>Product</Breadcrumb.Section>
      </Breadcrumb>
  </Segment>
  
     {!this.state.loading?( 
       <Grid centered columns ={3}>
       <Grid.Row>
       <Grid.Column>
     <Card >
     <Header textAlign = 'center' size = 'huge'>{`${this.state.data.title}`}</Header>
     
    <Image src={this.state.image.url} size = 'medium'/>
    <Card.Content>
      <Card.Header>{this.state.data.username}</Card.Header>
      <Card.Meta>
        <span className='date'>{this.state.data.birthdate}</span>
      </Card.Meta>
      <Card.Description as = 'h2'>{this.state.data.description}</Card.Description>
      <Card.Description  as = 'h5'><b>Username:</b> {this.state.users.username}
  
      </Card.Description>
      <Card.Description as = 'h5'><b>E-mail:</b> {this.state.users.email}</Card.Description>
    
      <Card.Description as = 'h5'><b>Commision:</b> {this.state.data.commision}</Card.Description>
      <Card.Description as = 'h5'><b>Postal code:</b> {this.state.data.postal_code}
      </Card.Description>
      <Card.Description as = 'h5'><b>User Rating:</b> {this.state.data.user_rating}
      </Card.Description>
      <Card.Description as = 'h5'><Button primary icon labelPosition='right' disabled>Price: <Icon name='money bill alternate outline' /></Button>                {this.state.data.price}
      </Card.Description>
    </Card.Content>
    <Card.Content extra>
    DT: {this.state.data.created_at}
    </Card.Content>

     </Card>
     </Grid.Column>
     </Grid.Row>
      </Grid>
     ):null}
    
     </div>
    )
  }
}
let mapStateToProps = (state) => {
  return {
  authen: state.auth,
  };
};
export default connect(mapStateToProps)(Product)