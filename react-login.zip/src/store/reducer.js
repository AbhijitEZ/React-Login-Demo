
let initalState ={
  auth : null
}
let reducer = (state = initalState, action) => {
  if(action.type  === 'AUTHENTICATION'){
    return {
      ...state,
      auth : action.payload.val
    }
  }
  return {
  ...state
  }
}

export default reducer;