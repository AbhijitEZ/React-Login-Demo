import React,{Component} from 'react';
import {Header, Input,  Button,   Grid,  Segment, Card, Image } from 'semantic-ui-react';
import {Link} from 'react-router-dom';
import './style/Listing.css'
import {connect} from 'react-redux';
class ProductListing extends Component{

constructor(props){
  super(props);
  this.state = {data : null, loading : true, keyword : null, auth: this.props.authen};
}
  

setData(){
    let fetchObj = {
      method: 'POST', 
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization' : 'Bearer ' + this.state.auth
      }
    }
    fetch('http://139.59.87.122/modtod/beta/api/product/productListings', fetchObj)
    .then(res => {
      if(res.status !==200){
        console.log(this.props.authen)
        throw new Error('WRONG FETCH');
      }
      else{
        return res.json();
      }
    })
    .then(result => 
      this.setState({data : result.data, loading: false})
      
    )
}

  filterValue(e){
    this.setState({keyword: e.target.value});
   console.log(this.state.keyword)
  }

  SearchData(e){
    if(this.state.keyword === null){
      console.log('nothing');
    }
    else{
    let dataTitle = this.state.data.filter(ele => ele.title === this.state.keyword)
    this.setState({data : dataTitle});
    }
  }

    render(){
       
      return (
        <div>
        <Segment>
        <Header as = 'h2'>Product</Header>
       
        </Segment>
        <Segment>
          <Button primary onClick ={() => this.setData()}>Data</Button>
          <Input type = 'text' onChange = {(event) => this.filterValue(event)}/>
          <Button secondary onClick ={(e) => this.SearchData(e)}>Search</Button>
          <Link to = '/'><Button primary floated = 'right' >LogOut</Button></Link>
          </Segment>
          <Grid columns ={3}>
          { !this.state.loading ? this.state.data.map(ele =>(
            <div key = {ele.id}>
              <Grid.Column>
              <Card className = 'card-view' color = 'blue'>
              <Link to ={`/product/detail/${ele.id}`}>
                <Image src={ele.images[0].url} />
                </Link>
                <Card.Content>
                  <Card.Header>{ele.title}</Card.Header>
                  <Card.Meta>
                    <span className='date'>Price: {ele.price}</span>
                  </Card.Meta>
                  <Card.Description>{ele.description}.</Card.Description>
                </Card.Content>
                <Card.Content extra>
                {ele.created_at}
                </Card.Content>
              </Card>
              </Grid.Column>
      
            </div>
          )) : null}
          </Grid>
        
        </div>
      )
    }
}

let mapStateToProps = (state) => {
  return {
  authen: state.auth,
  };
};
export default connect(mapStateToProps)(ProductListing);